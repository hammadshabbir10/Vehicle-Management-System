document.getElementById("backButton").addEventListener("click", function () {
    window.location.href = "mainpage.html";
});


document.getElementById("checkInForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent default form submission

    const vehicleNumber = document.getElementById("checkInVehicleNumber").value;
    const userEmail = localStorage.getItem("userEmail"); // Retrieve stored user email

    if (!userEmail) {
        alert("User email not found. Please log in.");
        return;
    }

    fetch("http://localhost:8081/api/vehicle/checkin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_email: userEmail, vehicle_number: vehicleNumber }),
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("message").innerText = data.message;
    })
    .catch(error => console.error("Error:", error));
});
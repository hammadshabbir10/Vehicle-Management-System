document.addEventListener("DOMContentLoaded", function () {
    const logoutBtn = document.getElementById("logoutBtn");
    const modal = document.getElementById("slotModal");
    const openModalBtn = document.getElementById("openSlotModal");
    const closeModal = document.querySelector(".close");
    const addSlotBtn = document.getElementById("addSlotBtn");
    const viewSlotsBtn = document.getElementById("viewSlotsBtn");
    const slotContainer = document.getElementById("slotContainer");
    const slotTableBody = document.getElementById("slotTableBody");

    logoutBtn.addEventListener("click", function () {
        localStorage.removeItem("user");
        window.location.href = "login.html";
    });

    openModalBtn.addEventListener("click", () => {
        modal.style.display = "block";
    });

    closeModal.addEventListener("click", () => {
        modal.style.display = "none";
    });

    window.addEventListener("click", (event) => {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });

    addSlotBtn.addEventListener("click", () => {
        const slotTime = document.getElementById("slotTime").value.trim();

        if (!slotTime) {
            alert("Please enter a slot time.");
            return;
        }

        fetch("http://localhost:8081/api/addSlot", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ slot_time: slotTime }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Slot added successfully!");
                modal.style.display = "none";
                location.reload(); 
            } else {
                alert("Failed to add slot: " + data.message);
            }
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Something went wrong.");
        });
    });

    viewSlotsBtn.addEventListener("click", () => {
        fetch("http://localhost:8081/api/slots")
            .then(response => response.json())
            .then(data => {
                slotTableBody.innerHTML = ""; // Clear previous data
                if (data.length === 0) {
                    slotTableBody.innerHTML = `<tr><td colspan="2">No slots available</td></tr>`;
                } else {
                    data.forEach(slot => {
                        const row = `<tr>
                                        <td>${slot.id}</td>
                                        <td>${slot.slot_time}</td>
                                    </tr>`;
                        slotTableBody.innerHTML += row;
                    });
                }
                slotContainer.style.display = "block"; // Show table
            })
            .catch(error => {
                console.error("Error fetching slots:", error);
                alert("Failed to fetch slots.");
            });
    });

});

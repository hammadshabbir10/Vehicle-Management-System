Create DATABASE VMS;

USE VMS;

CREATE TABLE Users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE Admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE Slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slot_time VARCHAR(50) NOT NULL UNIQUE, -- Example: '10:00 AM - 11:00 AM'
    status ENUM('available', 'booked') DEFAULT 'available'
);

CREATE TABLE Bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    slot_id INT NOT NULL,
    booking_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE,
    FOREIGN KEY (slot_id) REFERENCES Slots(id) ON DELETE CASCADE
);

INSERT INTO Slots (slot_time) VALUES 
('09:00 AM - 12:00 PM'),
('12:00 PM - 03:00 PM'),
('03:00 PM - 06:00 PM'),
('06:00 PM - 09:00 PM'),
('09:00 PM - 12:00 AM');




INSERT INTO Users (username, email, password) 
VALUES ('testuser', 'test@example.com', 'testpassword');

Select * from Users;
Select * from Admins;
Select * from Slots;
Select * from Bookings;



const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const db = require("./db"); 
const userRoutes = require("./userInsert"); 
const userLogin = require("./userLogin");
const users = require("./users");
const vehicleLogsRoutes = require("./vehicleLogs");
const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use("/api/user", userRoutes); 
app.use("/api/auth", userLogin);
app.use("/api",users);
app.use("/api/vehicle", vehicleLogsRoutes);

const session = require("express-session");


app.use(session({
    secret: "your_secret_key",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } 
}));

app.get("/api/check-login", (req, res) => {
    if (req.session.userId) {
        res.json({ loggedIn: true });
    } else {
        res.json({ loggedIn: false });
    }
});

app.get("/api/get-user", (req, res) => {
    if (req.session.userId) {
        res.json({ id: req.session.userId });
    } else {
        res.status(401).json({ message: "Not logged in" });
    }
});
app.post("/api/login", (req, res) => {
    console.log("Received Login Request");

    if (!req.body || !req.body.email || !req.body.password) {
        console.error("Missing email or password in request body", req.body);
        return res.status(400).json({ success: false, message: "Email and password required" });
    }

    const { email, password } = req.body;
    console.log("Login attempt:", email);

    // First, check in Users table
    const userQuery = "SELECT * FROM Users WHERE email = ?";
    db.query(userQuery, [email], (err, userResults) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: "Server error" });
        }

        if (userResults.length > 0) {
            const user = userResults[0];

            if (user.password !== password) {
                console.log("Incorrect password for:", email);
                return res.status(401).json({ success: false, message: "Incorrect password" });
            }

            console.log("User login successful for:", email);
            return res.json({ success: true, message: "Login successful", user: { id: user.id, role: "user" } });
        }

        // If not found in Users, check in Admins
        const adminQuery = "SELECT * FROM Admins WHERE email = ?";
        db.query(adminQuery, [email], (err, adminResults) => {
            if (err) {
                console.error("Database error:", err);
                return res.status(500).json({ success: false, message: "Server error" });
            }

            if (adminResults.length > 0) {
                const admin = adminResults[0];

                if (admin.password !== password) {
                    console.log("Incorrect password for:", email);
                    return res.status(401).json({ success: false, message: "Incorrect password" });
                }

                console.log("Admin login successful for:", email);
                return res.json({ success: true, message: "Login successful", user: { id: admin.id, role: "admin" } });
            }

            // If neither User nor Admin is found
            console.log("Invalid login attempt for email:", email);
            return res.status(401).json({ success: false, message: "Invalid email or password" });
        });
    });
});

/*
app.post("/api/login", (req, res) => {
    console.log("Received Login Request");

    if (!req.body || !req.body.email || !req.body.password) {
        console.error("Missing email or password in request body", req.body);
        return res.status(400).json({ success: false, message: "Email and password required" });
    }

    const { email, password } = req.body;
    console.log("Login attempt:", email);

    const query = "SELECT * FROM Users WHERE email = ?";
    db.query(query, [email], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: "Server error" });
        }

        if (results.length === 0) {
            console.log("User not found for email:", email);
            return res.status(401).json({ success: false, message: "Invalid email or password" });
        }

        const user = results[0];

        if (user.password !== password) {
            console.log("Incorrect password for:", email);
            return res.status(401).json({ success: false, message: "Incorrect password" });
        }

        console.log("Login successful for:", email);
        res.json({ success: true, message: "Login successful", user: { id: user.id, role: user.role } });
    });
});

*/
// Logout Route
app.get("/api/logout", (req, res) => {
    req.session.destroy(() => {
        res.json({ message: "Logged out successfully" });
    });
});


app.post("/api/addSlot", (req, res) => {
    const { slot_time } = req.body;

    if (!slot_time) {
        return res.status(400).json({ success: false, message: "Slot time is required" });
    }

    const query = "INSERT INTO Slots (slot_time, status) VALUES (?, 'available')";
    db.query(query, [slot_time], (err, result) => {
        if (err) {
            console.error("Error adding slot:", err);
            return res.status(500).json({ success: false, message: "Database error" });
        }
        res.json({ success: true, message: "Slot added successfully", slotId: result.insertId });
    });
});

app.get("/api/slots", (req, res) => {
    console.log("Fetching available slots...");
    
    db.query("SELECT id, slot_time FROM Slots WHERE status = 'available'", (err, results) => {
        if (err) {
            console.error("Database error:", err.sqlMessage || err);
            return res.status(500).json({ message: "Database error" });
        }

        if (results.length === 0) {
            console.warn("No available slots found.");
            return res.status(404).json({ message: "No slots available" });
        }

        console.log("Slots fetched:", results);
        res.json(results);
    });
});


app.post("/api/book-slot", (req, res) => {
    const { email, slotId } = req.body; // ✅ Make sure email is extracted

    if (!email || !slotId || isNaN(slotId)) {
        return res.status(400).json({ message: "Invalid Email or Slot ID" });
    }

    // Check if the email exists in the Users table
    const checkUserQuery = "SELECT id FROM Users WHERE email = ?";
    db.query(checkUserQuery, [email], (err, results) => {
        if (err) {
            console.error("Error checking user:", err);
            return res.status(500).json({ message: "Error verifying user" });
        }

        if (results.length === 0) {
            return res.status(400).json({ message: "User not found!" });
        }

        const userId = results[0].id; // ✅ Get the user's ID from DB

        // Check if the slot is available
        const checkSlotQuery = "SELECT status FROM Slots WHERE id = ?";
        db.query(checkSlotQuery, [slotId], (err, slotResults) => {
            if (err) {
                console.error("Error checking slot:", err);
                return res.status(500).json({ message: "Error checking slot availability" });
            }

            if (slotResults.length === 0) {
                return res.status(404).json({ message: "Slot not found" });
            }

            if (slotResults[0].status === "booked") {
                return res.status(400).json({ message: "Slot already booked!" });
            }

            // Book the slot
            const insertQuery = "INSERT INTO Bookings (user_id, slot_id) VALUES (?, ?)";
            db.query(insertQuery, [userId, slotId], (err, result) => {
                if (err) {
                    console.error("Error booking slot:", err);
                    return res.status(500).json({ message: "Error booking slot" });
                }

                // Update slot status to 'booked'
                const updateSlotQuery = "UPDATE Slots SET status = 'booked' WHERE id = ?";
                db.query(updateSlotQuery, [slotId], (updateErr) => {
                    if (updateErr) {
                        console.error("Error updating slot status:", updateErr);
                        return res.status(500).json({ message: "Error updating slot status" });
                    }
                    res.json({ message: "Slot booked successfully!" });
                });
            });
        });
    });
});


app.get("/api/bookings", (req, res) => {
    const email = req.query.email;

    if (!email) {
        return res.status(400).json({ message: "Email is required" });
    }

    const query = `
        SELECT Bookings.id, Slots.slot_time, Bookings.booking_time 
        FROM Bookings
        JOIN Slots ON Bookings.slot_id = Slots.id
        JOIN Users ON Bookings.user_id = Users.id
        WHERE Users.email = ?
    `;

    db.query(query, [email], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ message: "Database error" });
        }
        res.json(results);
    });
});

app.delete("/api/bookings/:id", (req, res) => {
    const bookingId = req.params.id;

    db.query("SELECT slot_id FROM Bookings WHERE id = ?", [bookingId], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ success: false, message: "Database error" });
        }

        if (results.length === 0) {
            return res.status(404).json({ success: false, message: "Booking not found" });
        }

        const slotId = results[0].slot_id;

        db.query("DELETE FROM Bookings WHERE id = ?", [bookingId], (err, deleteResult) => {
            if (err) {
                console.error("Database error:", err);
                return res.status(500).json({ success: false, message: "Database error" });
            }

            db.query("UPDATE Slots SET status = 'available' WHERE id = ?", [slotId], (err, updateResult) => {
                if (err) {
                    console.error("Error updating slot status:", err);
                    return res.status(500).json({ success: false, message: "Failed to update slot status" });
                }

                res.json({ success: true, message: "Booking canceled and slot updated to available" });
            });
        });
    });
});


const PORT = process.env.PORT || 8081;

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

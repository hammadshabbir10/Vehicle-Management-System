/*
const express = require("express");
const db = require("./db");
const router = express.Router();

router.post("/login", (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "All fields are required!" });
    }
    const checkUserSql = "SELECT id, email, username FROM Users WHERE email = ? AND password = ?";
    db.query(checkUserSql, [email, password], (err, userResults) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ message: "Database error" });
        }

        if (userResults.length > 0) {
            const user = userResults[0];
            return res.status(200).json({ 
                message: "Login successful!", 
                user: { id: user.id, email: user.email, name: user.username, role: "user" }
            });
        }
        const checkAdminSql = "SELECT id, email, username FROM Admins WHERE email = ? AND password = ?";
        db.query(checkAdminSql, [email, password], (err, adminResults) => {
            if (err) {
                console.error("Database error:", err);
                return res.status(500).json({ message: "Database error" });
            }

            if (adminResults.length > 0) {
                const admin = adminResults[0];
                return res.status(200).json({ 
                    message: "Login successful!", 
                    user: { id: admin.id, email: admin.email, name: admin.username, role: "admin" }
                });
            }
            return res.status(401).json({ message: "Invalid email or password!" });
        });
    });
});

module.exports = router;

*/
const express = require("express");
const db = require("./db");
const router = express.Router();

router.post("/login", (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "All fields are required!" });
    }

    const checkUserSql = `
        SELECT id, email, username, password, 'user' as role FROM Users WHERE email = ? 
        UNION 
        SELECT id, email, username, password, 'admin' as role FROM Admins WHERE email = ?
    `;

    db.query(checkUserSql, [email, email], (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ message: "Database error" });
        }

        if (results.length === 0) {
            console.log("User not found for email:", email);
            return res.status(401).json({ message: "Invalid email or password!" });
        }

        const user = results[0];

        // Compare entered password with hashed password in DB
        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (err) {
                console.error("Error comparing passwords:", err);
                return res.status(500).json({ message: "Server error" });
            }

            if (!isMatch) {
                console.log("Incorrect password for:", email);
                return res.status(401).json({ message: "Invalid email or password!" });
            }

            console.log("Login successful for:", email);
            res.status(200).json({ 
                message: "Login successful!", 
                user: { id: user.id, email: user.email, name: user.username, role: user.role }
            });
        });
    });
});

module.exports = router;

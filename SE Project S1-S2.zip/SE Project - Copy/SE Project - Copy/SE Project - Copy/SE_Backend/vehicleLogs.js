const express = require("express");
const router = express.Router();
const db = require("./db");

// Vehicle Check-in
router.post("/checkin", (req, res) => {
    const { user_email, vehicle_number } = req.body;

    if (!user_email || !vehicle_number) {
        return res.status(400).json({ error: "User email and vehicle number are required" });
    }

    // Get User ID
    const getUserQuery = "SELECT id FROM Users WHERE email = ?";
    db.query(getUserQuery, [user_email], (err, userResults) => {
        if (err) {
            console.error("Error fetching user:", err);
            return res.status(500).json({ error: "Database error" });
        }

        if (userResults.length === 0) {
            return res.status(400).json({ error: "User not found" });
        }

        const userId = userResults[0].id;

        // Check if the vehicle is already checked in (by any user)
        const checkVehicleQuery = `
            SELECT * FROM VehicleLogs 
            WHERE vehicle_number = ? 
            AND check_out_time IS NULL
        `;

        db.query(checkVehicleQuery, [vehicle_number], (err, vehicleResults) => {
            if (err) {
                console.error("Error checking vehicle logs:", err);
                return res.status(500).json({ error: "Database error" });
            }

            if (vehicleResults.length > 0) {
                return res.status(400).json({ error: "This vehicle is already checked in by another user" });
            }

            // Check if the user has a valid booking for the current time
            const checkBookingQuery = `
                SELECT b.id AS booking_id, b.slot_id, s.status
                FROM Bookings b
                JOIN Slots s ON b.slot_id = s.id
                WHERE b.user_id = ? 
                AND s.status = 'booked' 
                AND b.booking_time <= NOW() 
                AND TIMESTAMPADD(HOUR, 2, b.booking_time) >= NOW()
            `;

            db.query(checkBookingQuery, [userId], (err, bookingResults) => {
                if (err) {
                    console.error("Error checking booking:", err);
                    return res.status(500).json({ error: "Database error" });
                }

                if (bookingResults.length === 0) {
                    return res.status(400).json({ error: "No valid booking found for check-in" });
                }

                const bookingId = bookingResults[0].booking_id;
                const slotId = bookingResults[0].slot_id;

                // Proceed with check-in: Insert into VehicleLogs with user email & ID
                const insertVehicleLogQuery = `
                    INSERT INTO VehicleLogs (user_id, user_email, vehicle_number, check_in_time) 
                    VALUES (?, ?, ?, NOW())
                `;

                db.query(insertVehicleLogQuery, [userId, user_email, vehicle_number], (err) => {
                    if (err) {
                        console.error("Error in check-in:", err);
                        return res.status(500).json({ error: "Error logging vehicle check-in" });
                    }

                    // Update slot status to 'used' in Slots table
                    const updateSlotQuery = "UPDATE Slots SET status = 'used' WHERE id = ?";
                    db.query(updateSlotQuery, [slotId], (err) => {
                        if (err) {
                            console.error("Error updating slot status:", err);
                            return res.status(500).json({ error: "Error updating slot status" });
                        }

                        res.json({ success: true, message: "Check-in successful!" });
                    });
                });
            });
        });
    });
});
// Vehicle Check-out
router.post("/checkout", (req, res) => {
    const { user_email, vehicle_number } = req.body;

    if (!user_email || !vehicle_number) {
        return res.status(400).json({ error: "User email and vehicle number are required" });
    }

    // Find the last check-in record for this vehicle
    const findQuery = `
        SELECT vl.id, vl.check_in_time, b.slot_id 
        FROM VehicleLogs vl
        JOIN Bookings b ON b.user_id = vl.user_id
        WHERE vl.user_email = ? 
        AND vl.vehicle_number = ? 
        AND vl.check_out_time IS NULL 
        ORDER BY vl.check_in_time DESC LIMIT 1`;

    db.query(findQuery, [user_email, vehicle_number], (err, results) => {
        if (err) {
            console.error("Error finding check-in record:", err);
            return res.status(500).json({ error: "Database error" });
        }

        if (results.length === 0) {
            return res.status(400).json({ error: "No active check-in record found for this vehicle" });
        }

        const checkInTime = new Date(results[0].check_in_time);
        const checkOutTime = new Date(); // Current time
        const logId = results[0].id;
        const slotId = results[0].slot_id; // Get the booked slot ID

        // Calculate duration in hours
        const durationMs = checkOutTime - checkInTime;
        const durationHours = Math.ceil(durationMs / (1000 * 60 * 60)); // Convert milliseconds to hours and round up

        // Fee per hour
        const feeRate = 100; // Change this value if needed
        const totalFee = durationHours * feeRate;

        // Update checkout time and fee in the database
        const updateQuery = `
            UPDATE VehicleLogs 
            SET check_out_time = NOW(), total_fee = ? 
            WHERE id = ?`;

        db.query(updateQuery, [totalFee, logId], (err) => {
            if (err) {
                console.error("Error updating checkout:", err);
                return res.status(500).json({ error: "Database error during checkout" });
            }

            // Update slot status to 'available' again
            const updateSlotQuery = "UPDATE Slots SET status = 'available' WHERE id = ?";
            db.query(updateSlotQuery, [slotId], (err) => {
                if (err) {
                    console.error("Error updating slot status:", err);
                    return res.status(500).json({ error: "Error updating slot status" });
                }

                return res.status(200).json({ 
                    message: "Vehicle checked out successfully!", 
                    duration: durationHours, 
                    total_fee: totalFee 
                });
            });
        });
    });
});

module.exports = router;

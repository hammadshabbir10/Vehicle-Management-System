const express = require("express");
const db = require("./db");
const router = express.Router();

router.get("/users", (req, res) => {
    const sql = "SELECT id, username AS name, email FROM Users";
    db.query(sql, (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ message: "Database error" });
        }
        res.json(results);
    });
});

module.exports = router;
